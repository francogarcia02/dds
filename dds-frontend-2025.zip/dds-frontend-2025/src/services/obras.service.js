import axios from "axios";
//const urlResource = "https://labsys.frc.utn.edu.ar/dds-backend-2025/api/obra";
const urlResource = "http://localhost:3000/api/obra";
//const urlResource = "https://pymes2025.azurewebsites.net/api/obra";


const Buscar = async () => {
    try {
        const obras = await axios.get(urlResource)
        return obras
    } catch (error) {
        return{error: error}
    }
}

const BuscarPorArtista = async ({artista}) => {
    try {
        const obras = await axios.get(urlResource+`/${artista}`)
        return obras
    } catch (error) {
        return{error: error}
    }
}

export const obrasService = {
  Buscar, BuscarPorArtista
};