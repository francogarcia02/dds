import { useEffect, useState } from "react"
import { obrasService } from "../services/obras.service"
import { ObraItem } from "./obras/ObraItem"
import { ObraSearcher } from "./obras/ObraSearcher"

const Obras = () => {
    const [obras, setObras] = useState([])

    useEffect(() => {
        const fetchObras = async () => {
            const obrasFetch = await obrasService.Buscar()
            const obrasPorArtistaFetch = await obrasService.BuscarPorArtista({artista: 'pab'})
            console.log(obrasPorArtistaFetch)
            if (obrasFetch.error) {
                console.log(obrasFetch)
            } else {
                setObras(obrasFetch.data)
            }
        }
        fetchObras()
    }, [])

    return (
        <div>
            <h2>Listado de Obras</h2>
            <ObraSearcher setObras={setObras}/>
            {obras.length === 0 ? (
                <p>No hay obras cargadas.</p>
            ) : (
                <ul>
                    {obras.map((obra) => (
                        <ObraItem obra={obra} key={obra.IdObra}/>
                    ))}
                </ul>
            )}
        </div>
    )
}

export { Obras }
