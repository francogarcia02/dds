const ObraItem = ({ obra }) => {
    return (
        <div style={{ margin: "15px" }}>
            <h5>{obra.Titulo}</h5>
            <p>Artista: {obra.Artista}</p>
            <p>Fecha de ingreso: {obra.FechaIngreso}</p>
            <p>Valor estimado: ${obra.ValorEstimadoPesos}</p>
            <p>En exhibición: {obra.EnExhibicion ? "Sí" : "No"}</p>
        </div>
    )
}

export { ObraItem }
