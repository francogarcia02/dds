import { useState } from "react"
import { obrasService } from "../../services/obras.service"

const ObraSearcher = ({ setObras }) => {
    const [artista, setArtista] = useState("")

    const search = async () => {
        const result = await obrasService.BuscarPorArtista({ artista })

        if (result.error) {
            console.log(result)
        } else {
            setObras(result.data || result)
        }
    }

    return (
        <div style={{ margin: "10px 0" }}>

            <style>
                {`
                    .search-input {
                        padding: 8px 12px;
                        border-radius: 8px;
                        border: 1px solid #ccc;
                        margin-right: 8px;
                        font-size: 14px;
                        text-transform: none !important;
                    }

                    .search-button {
                        padding: 8px 16px;
                        border-radius: 8px;
                        border: none;
                        background-color: #007bff;
                        color: white;
                        cursor: pointer;
                        transition: background-color 0.2s ease;
                    }

                    .search-button:hover {
                        background-color: #0056b3;
                    }
                `}
            </style>

            <input
                className="search-input"
                type="text"
                placeholder="Buscar por artista..."
                value={artista}
                onChange={(e) => setArtista(e.target.value)}
            />

            <button className="search-button" onClick={search}>
                Buscar
            </button>
        </div>
    )
}

export { ObraSearcher }
