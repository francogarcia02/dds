const express = require("express");
const router = express.Router();
const { Op } = require("sequelize");
const Obra = require('../models/obraModel'); 

router.get('/api/obra', async (req, res) => {
  try {
    let options = {
      order: [['FechaIngreso', 'ASC']] 
    };

    const obras = await Obra.findAll(options);
    res.json(obras);

  } catch (error) {
    console.error("Error al obtener las obras:", error);
    res.status(500).json({ message: "Error interno del servidor al obtener obras." });
  }
});


router.get('/api/obra/:Artista', async (req, res) => {
  try {
    const { Artista } = req.params;

    let options = {
      where: {
        Artista: {
          [Op.like]: `%${Artista}%`
        }
      },
      order: [['FechaIngreso', 'ASC']]
    };

    const obras = await Obra.findAll(options);

    res.json(obras);

  } catch (error) {
    console.error("Error al obtener las obras por artista:", error);
    res.status(500).json({ message: "Error interno del servidor al obtener obras." });
  }
});

module.exports = router;