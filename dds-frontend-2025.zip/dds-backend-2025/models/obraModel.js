const { DataTypes } = require('sequelize');
// Asegúrate de que la ruta a tu configuración de Sequelize sea correcta
const sequelize = require('./configurarSequelize');

const Obra = sequelize.define(
  "obra", // Nombre del modelo (Sequelize pluralizará a 'obras' para la tabla)
  {
    IdObra: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    Titulo: {
      type: DataTypes.STRING(150), // Longitud aumentada para títulos de obras
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Titulo es requerido",
        },
        len: {
          args: [3, 150],
          msg: "Titulo debe tener entre 3 y 150 caracteres",
        },
      },
    },
    Artista: {
      type: DataTypes.STRING(100),
      allowNull: false,
      validate: {
        notEmpty: {
          args: true,
          msg: "Artista es requerido",
        },
        len: {
          args: [3, 100],
          msg: "Artista debe tener entre 3 y 100 caracteres",
        },
      },
    },
    FechaIngreso: {
      type: DataTypes.DATEONLY,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "FechaIngreso es requerida",
        },
        isDate: {
            args: true,
            msg: "FechaIngreso debe ser una fecha válida",
        }
      }
    },
    ValorEstimadoPesos: {
      type: DataTypes.DECIMAL(12, 2), // 12 dígitos en total, 2 después de la coma
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "ValorEstimadoPesos es requerido",
        },
        isDecimal: {
            args: true,
            msg: "ValorEstimadoPesos debe ser un número decimal",
        },
        min: {
            args: [0], // El valor no puede ser negativo
            msg: "ValorEstimadoPesos no puede ser negativo",
        }
      }
    },
    EnExhibicion: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      validate: {
        notNull: {
          args: true,
          msg: "EnExhibicion es requerido (true o false)",
        }
      }
    },
  },
  {
    // Opciones del modelo
    hooks: {
      beforeValidate: function (obra, options) {
        // Solo quitamos espacios al inicio y final, no forzamos mayúsculas
        // ya que los títulos y nombres de artistas suelen tener mayúsculas y minúsculas.
        if (typeof obra.Titulo === "string") {
          obra.Titulo = obra.Titulo.trim();
        }
        if (typeof obra.Artista === "string") {
          obra.Artista = obra.Artista.trim();
        }
      },
    },
    timestamps: false, // Deshabilitamos timestamps (createdAt, updatedAt)
  }
);

module.exports = Obra;