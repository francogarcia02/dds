import { Routes, Route, Navigate } from 'react-router-dom'
import Navbar from './components/Navbar.jsx'
import Inicio from './pages/Inicio.jsx'
import Usuarios from './pages/Usuarios.jsx'
import Publicaciones from './pages/Publicaciones.jsx'
import Error404 from './pages/Error404.jsx'

import PublicacionDetalle from './pages/PublicacionDetalle.jsx'


import './styles/App.css'
import './styles/Inicio.css'
import './styles/Navbar.css'



export default function App() {
  return (
    <div className="layout">
      <Navbar />
      <main className="content">
        <Routes>
          <Route path="/inicio" element={<Inicio />} />
          <Route path="/usuarios" element={<Usuarios />} />
          <Route path="/publicaciones" element={<Publicaciones />} />

          <Route path="/publicaciones/:id" element={<PublicacionDetalle />} />
          <Route path="/usuarios/:id/publicaciones" element={<Publicaciones />} />

          <Route path="*" element={<Error404 />} />
        </Routes>
      </main>
    </div>
  )
}
