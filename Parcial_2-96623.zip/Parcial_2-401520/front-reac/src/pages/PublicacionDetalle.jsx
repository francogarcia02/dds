import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { get } from '../services/api.js';
import { crearComentario, borrarComentario } from '../services/api.js';
import Cargando from '../components/Cargando.jsx';
import Alerta from '../components/Alerta.jsx';
import ComentarioForm from '../components/ComentarioForm.jsx';

export default function PublicacionDetalle() {
const { id } = useParams();

const [pub, setPub] = useState(null);
const [comentarios, setComentarios] = useState([]);
const [loading, setLoading] = useState(true);
const [errorPub, setErrorPub] = useState('');
const [errorCom, setErrorCom] = useState('');
const [errorUi, setErrorUi] = useState('');
const [posting, setPosting] = useState(false);

useEffect(() => {
    let activo = true;
    setLoading(true);
    setErrorPub(''); setErrorCom(''); setErrorUi('');
    setPub(null); setComentarios([]);

    Promise.allSettled([
    get(`/publicaciones/${id}`),
    get(`/publicaciones/${id}/comentarios`)
    ]).then(([rPub, rCom]) => {
    if (!activo) return;

    if (rPub.status === 'fulfilled') {
        const d = rPub.value;
        d?.error ? setErrorPub(d.mensaje) : setPub(d || null);
    } else {
        setErrorPub(rPub.reason?.message || 'Error al cargar la publicación');
    }

    if (rCom.status === 'fulfilled') {
        const d = rCom.value;
        d?.error ? setErrorCom(d.mensaje) : setComentarios(Array.isArray(d) ? d : []);
    } else {
        setErrorCom(rCom.reason?.message || 'Error al cargar comentarios');
    }
    }).finally(() => activo && setLoading(false));

    return () => { activo = false; };
}, [id]);


const handleCrear = async ({ nombre, correo, cuerpo }) => {
    setErrorUi('');
    setPosting(true);

    
    const temp = {
    id: 'tmp-' + Date.now(),
    autor: nombre,
    nombre,
    correo,
    cuerpo
    };
    setComentarios(prev => [temp, ...prev]);

    
    const res = await crearComentario(id, { nombre, correo, cuerpo });

    
    if (res?.error) {
    
    setComentarios(prev => prev.filter(c => c.id !== temp.id));
    setErrorUi(res.mensaje || 'No se pudo crear el comentario');
    } else {
    
    setComentarios(prev => {
        const arr = prev.filter(c => c.id !== temp.id);
        return [res, ...arr];
    });
    }

    setPosting(false);
};


const handleBorrar = async (comentarioId) => {
    setErrorUi('');
    const backup = comentarios;

    
    setComentarios(prev => prev.filter(c => c.id !== comentarioId));

    
    const res = await borrarComentario(comentarioId);

    
    if (res?.error) {
    setComentarios(backup); 
    setErrorUi(res.mensaje || 'No se pudo borrar el comentario');
    }
};

if (loading) return <Cargando texto="Cargando detalle…" />;

return (
    <section>
    <h1>Publicación #{id}</h1>

    
    {errorPub ? (
        <Alerta mensaje={errorPub} />
    ) : pub ? (
        <article className="post" style={{ marginBottom: 16 }}>
        <h3>{pub.titulo || `Publicación #${id}`}</h3>
        <p>{pub.cuerpo || '—'}</p>
        </article>
    ) : null}

    
    <h2>Agregar comentario</h2>
    {errorUi && <Alerta mensaje={errorUi} />}
    <ComentarioForm onSubmit={handleCrear} loading={posting} />

    
    <h2>Comentarios</h2>
    {errorCom && <Alerta mensaje={errorCom} />}

    {!errorCom && (comentarios.length === 0 ? (
        <p className="muted">Sin comentarios todavía.</p>
    ) : (
        <ul className="list">
        {comentarios.map(c => (
            <li key={c.id} className="post">
            <strong>{c.autor || c.nombre || 'Anónimo'}</strong>
            <p>{c.cuerpo || c.contenido || '—'}</p>
            
            {String(c.id).startsWith('tmp-') ? (
                <button className="secondary" disabled>Guardando…</button>
            ) : (
                <button className="danger" onClick={() => handleBorrar(c.id)}>
                Borrar
                </button>
            )}
            </li>
        ))}
        </ul>
    ))}
    </section>
);
}
