export default function Error404() {
  return <h2>Esta direccion no existe</h2>
}
