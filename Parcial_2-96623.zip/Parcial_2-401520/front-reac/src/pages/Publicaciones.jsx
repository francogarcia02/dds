import { useEffect, useState, useMemo } from 'react'
import { useParams, useSearchParams, Link } from 'react-router-dom'
import { getPublicaciones } from '../services/api.js'
import Cargando from '../components/Cargando.jsx'


import Alerta from '../components/Alerta.jsx'

export default function Publicaciones() {
const { id } = useParams()
const [searchParams, setSearchParams] = useSearchParams()
const [items, setItems] = useState([])
const [loading, setLoading] = useState(true)
const [error, setError] = useState('')


const filtroInicial = searchParams.get('filtro') || ''
const ordenInicial = searchParams.get('orden') || 'fecha_desc'

const [query, setQuery] = useState(filtroInicial)
const [filtro, setFiltro] = useState(filtroInicial)
const [orden, setOrden] = useState(ordenInicial)

useEffect(() => {
    (async () => {
    const data = await getPublicaciones({ usuarioId: id })
    if (data.error) {
        setError(data.mensaje)
    } else {
        setItems(Array.isArray(data) ? data : [])
    }
    setLoading(false)
    })()
}, [id])

const view = useMemo(() => {
    let result = items

    if (filtro.trim()) {
    const q = filtro.toLowerCase()
    result = result.filter(p =>
        (p.titulo || '').toLowerCase().includes(q) ||
        (p.cuerpo || '').toLowerCase().includes(q)
    )
    }

    result = [...result]
    switch (orden) {
    case 'fecha_desc': result.sort((a,b)=>new Date(b.fecha)-new Date(a.fecha)); break
    case 'fecha_asc':  result.sort((a,b)=>new Date(a.fecha)-new Date(b.fecha)); break
    case 'titulo_az':  result.sort((a,b)=>a.titulo.localeCompare(b.titulo)); break
    case 'titulo_za':  result.sort((a,b)=>b.titulo.localeCompare(a.titulo)); break
    default: break
    }
    return result
}, [items, filtro, orden])

useEffect(() => {
    const params = {}
    if (filtro) params.filtro = filtro
    if (orden) params.orden = orden
    setSearchParams(params)
}, [filtro, orden, setSearchParams])

const handleSearch = () => setFiltro(query)
const handleClear = () => { setQuery(''); setFiltro('') }

if (loading) return <Cargando texto="Cargando publicaciones…" />

return (
    <section>
    <h1>Publicaciones del Usuario #{id}</h1>
    {error && <Alerta mensaje={error} />}

    <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <input
        type="text"
        placeholder="Buscar por título o cuerpo"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        style={{ padding: '6px', flex: 1 }}
        />
        <button onClick={handleSearch}>Buscar</button>
        <button onClick={handleClear} type="button">Limpiar</button>

        <select value={orden} onChange={(e) => setOrden(e.target.value)}>
        <option value="fecha_desc">Fecha ↓</option>
        <option value="fecha_asc">Fecha ↑</option>
        <option value="titulo_az">Título A-Z</option>
        <option value="titulo_za">Título Z-A</option>
        </select>
    </div>

    {view.length === 0 ? (
        <p className="muted">Sin publicaciones para mostrar.</p>
    ) : (
        <ul className="list">
        {view.map(p => (
            <li key={p.id} className="post">
            <h3>{p.titulo || `Publicación #${p.id}`}</h3>
            <p>{p.cuerpo || '—'}</p>
            {p.fecha && <small className="muted">{new Date(p.fecha).toLocaleDateString()}</small>}
            
            
            <Link
                to={`/publicaciones/${p.id}`}
                className="boton"
                style={{ display: 'inline-block', marginTop: '6px' }}
            >Ver detalle</Link>
            </li>
        ))}
        </ul>
    )}
    </section>
)
}
