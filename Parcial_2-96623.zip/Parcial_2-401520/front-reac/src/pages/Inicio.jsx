export default function Inicio() {
    return (
        <section>
        
        <h1>Mini-Red Social</h1>
        <h2>Examen Parcial 2</h2>
        
        
        


        <footer>
            <h3>Desarrollado por Franco Garcia - DDS Curso: 3k1 </h3>
        </footer>
        </section>
    )
}
