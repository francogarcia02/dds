import { useEffect, useState } from 'react'
import { getUsuarios } from '../services/api.js'
import Cargando from '../components/Cargando.jsx'
import UsuarioCard from '../components/UsuarioCard.jsx'

import Alerta from '../components/Alerta.jsx'





export default function Usuarios() {
const [rows, setRows] = useState([])
const [loading, setLoading] = useState(true)
const [error, setError] = useState('')


const [pagina, setPagina] = useState(1)
const limite = 5

useEffect(() => {
    (async () => {
    const data = await getUsuarios()
    if (data.error) {
        setError(data.mensaje)
    } else {
        setRows(Array.isArray(data) ? data : [])
    }
    setLoading(false)
    })()
}, [])

if (loading) 
    return <Cargando texto="Cargando usuarios…" />


const inicio = (pagina - 1) * limite
const fin = inicio + limite
const usuariosPagina = rows.slice(inicio, fin)

return (
    <section>
    <h1>Usuarios</h1>
    {error && <Alerta mensaje={error} />}
    {usuariosPagina.length === 0 ? (
        <p></p>
    ) : (
        <div className="grid">
        {usuariosPagina.map(u => (
            <UsuarioCard key={u.id} u={u} />
        ))}
        </div>
    )}

    
    <div className="row" style={{ marginTop: '16px' }}>
        <button
        className="secondary"
        onClick={() => setPagina(p => p - 1)}
        disabled={pagina <= 1}
        >
        Anterior
        </button>

        <span>Página {pagina}</span>

        <button
        onClick={() => setPagina(p => p + 1)}
        disabled={fin >= rows.length}
        >
        Siguiente
        </button>
    </div>
    </section>
)
}
