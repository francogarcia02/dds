import axios from 'axios'


export const api = axios.create({
baseURL: 'http://localhost:4000/api',
headers: { 'Content-Type': 'application/json' }
})


function normalizarError(err) {
const mensaje =
    err.response?.data?.mensaje ||
    err.response?.data?.error ||
    err.message ||
    'Error al procesar la solicitud'
return { error: true, mensaje }
}


export async function get(url, params = {}) {
try {
    const { data } = await api.get(url, { params })
    return data
} catch (err) {
    return normalizarError(err)
}
}


export async function post(url, body = {}) {
try {
    const { data } = await api.post(url, body)
    return data
} catch (err) {
    return normalizarError(err)
}
}

export async function del(url) {
try {
    const { data } = await api.delete(url)
    return data
} catch (err) {
    return normalizarError(err)
}
}


export async function getUsuarios() {
const res = await get('/usuarios')
return res
}

export async function getPublicaciones({ usuarioId } = {}) {
const res = await get('/publicaciones', usuarioId ? { usuarioId } : {})
return res
}




export async function crearComentario(publicacionId, payload) {

return await post(`/publicaciones/${publicacionId}/comentarios`, payload);
}

export async function borrarComentario(comentarioId) {
return await del(`/comentarios/${comentarioId}`);
}
