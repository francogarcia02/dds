export default function Alerta({ mensaje }) {
if (!mensaje) return null

return (
    <div
    style={{
        background: 'rgba(239,68,68,0.15)',
        border: '1px solid rgba(239,68,68,0.4)',
        color: '#fecaca',
        padding: '10px 14px',
        borderRadius: '12px',
        margin: '8px 0'
    }}
    >
    {mensaje}
    </div>
)
}
