import { NavLink } from 'react-router-dom'

export default function Navbar() {
return (
    <nav className="navbar">

    <div className="nav-links">
        <NavLink to="/inicio">Inicio</NavLink>
        <NavLink to="/usuarios">Usuarios</NavLink>
        <NavLink to="/publicaciones">Publicaciones</NavLink>
    </div>
    </nav>
)
}
