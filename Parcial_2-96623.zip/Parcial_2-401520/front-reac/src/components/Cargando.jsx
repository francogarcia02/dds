export default function Cargando({ texto = 'Cargando…' }) {
    return <p className="loading">{texto}</p>
}
