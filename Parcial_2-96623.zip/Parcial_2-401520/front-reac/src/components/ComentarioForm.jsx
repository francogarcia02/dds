import { useState } from 'react';

export default function ComentarioForm({ onSubmit, loading = false }) {
const [nombre, setNombre] = useState('');
const [correo, setCorreo] = useState('');
const [cuerpo, setCuerpo] = useState('');

const [errores, setErrores] = useState({});

const validar = () => {
    const e = {};
    if (!nombre.trim()) e.nombre = 'Nombre requerido';
    if (!correo.trim()) e.correo = 'Correo requerido';
    if (!cuerpo.trim()) e.cuerpo = 'Comentario requerido';
    setErrores(e);
    return Object.keys(e).length === 0;
};

const handleSubmit = (ev) => {
    ev.preventDefault();
    if (!validar()) return;
    onSubmit({ nombre: nombre.trim(), correo: correo.trim(), cuerpo: cuerpo.trim() });
};

return (
    <form onSubmit={handleSubmit} style={{ marginBottom: 16 }}>
    <div className="row" style={{ marginBottom: 8 }}>
        <input
        type="text" placeholder="Nombre"
        value={nombre} onChange={(e) => setNombre(e.target.value)}
        />
        <input
        type="email" placeholder="Correo"
        value={correo} onChange={(e) => setCorreo(e.target.value)}
        />
    </div>
    {errores.nombre && <small className="muted">• {errores.nombre}</small>}
    {errores.correo && <small className="muted" style={{ marginLeft: 8 }}>• {errores.correo}</small>}
    <div style={{ marginTop: 8 }}>
        <textarea
        placeholder="Escribe tu comentario…" rows={3}
        value={cuerpo} onChange={(e) => setCuerpo(e.target.value)}
        style={{ width:'100%', padding:10, borderRadius:12, border:'1px solid var(--border)', background:'rgba(0,0,0,.2)', color:'var(--text)' }}
        />
        {errores.cuerpo && <small className="muted">• {errores.cuerpo}</small>}
    </div>
    <div style={{ marginTop: 8 }}>
        <button type="submit" disabled={loading}>{loading ? 'Enviando…' : 'Comentar'}</button>
    </div>
    </form>
);
}
