import { Link } from 'react-router-dom'

export default function UsuarioCard({ u }) {
  return (
    <article className="card">
      <h3>{u.nombre}</h3>
      <p>{u.correo}</p>
      <p>Ciudad: <u>{u.ciudad}</u></p>

      
      <div className="card-actions" >
        <Link to={`/usuarios/${u.id}/publicaciones`}>
        <button className='boton'>Ver publicaciones</button>

        </Link>
        
      </div>
    </article>
  )
}
