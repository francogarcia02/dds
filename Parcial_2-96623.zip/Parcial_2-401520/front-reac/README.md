        Como correr el proyecto=
Para corer el proyecto tenemos que dirigirnos a la carpeta backend para ejecutar en la consola lo siguiente (npm run dev) y eso levantara la api el el puerto 4000. podemos accedes desde el navegador o desde el postman.

Para el Frontend en react tenemos que citura nuetra terminal en front-reac para luego ejecutar en la terminal lo siguiente (npm run start). Y se abrira una pagina en chrome del projecto que va a estar en el puerto 5173.

        Diccionario de Endpoints en español=

----------------------------------USUARIOS----------------------------------

METODO GET

/usuarios
"Devuelbe todos los usuarios de la base de datos".

/usuarios/:id
"Devuelbe solo un registro que coincida con el id"

METODO POST
/usuarios
{ 
    "nombre": "Pepito Pepon", 
    "correo": "pepito@mail.com", 
    "ciudad": "Pepolandia" 
}
"Va a agregar un nuevo registro de usuario en formato JSON."

METODO PUT

/usuarios/:id
{ 
    "nombre": "Pepito Peli", 
    "correo": "pepito@mail.com", 
    "ciudad": "Pepolandia" 
}
"Va a modificar los atributos que quieras de un registro ya existente que coincida con el id enviado por parametro."

METODO DELETE

/usuarios/:id
"VA a borrar el registro de usuario que coincida con el id"


----------------------------------PUBLICACIONES----------------------------------
METODO GET

/publicaciones
"Devuelbe todos los publicaciones de la base de datos".

/publicaciones/:id
"Devuelbe solo un registro que coincida con el id"

METODO POST
/publicaciones
{ 
    "nombre": "Pepito Pepon", 
    "correo": "pepito@mail.com", 
    "ciudad": "Pepolandia" 
}
"Va a agregar un nuevo registro de publicaciones en formato JSON."

METODO PUT

/publicaciones/:id
{ 
    "nombre": "Pepito Peli", 
    "correo": "pepito@mail.com", 
    "ciudad": "Pepolandia" 
}
"Va a modificar los atributos que quieras de un registro ya existente que coincida con el id enviado por parametro."

METODO DELETE

/publicaciones/:id
"VA a borrar el registro de publicaciones que coincida con el id"


----------------------------------COMENTARIOS----------------------------------

METODO GET

/comentarios
"Devuelbe todos los comentarios de la base de datos"

METODO DELETE

/comentarios/:id
"VA a borrar el registro de comentarios que coincida con el id"

