import express from "express";
import cors from "cors";
import morgan from "morgan";
import { connectDB } from "./db.js";
import "./models/index.js";

import usuarios from "./routes/usuarios.routes.js";
import publicaciones from "./routes/publicaciones.routes.js";
import comentarios from "./routes/comentarios.routes.js";

const app = express();
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));




//Rutas
app.use("/api/usuarios", usuarios);
app.use("/api/publicaciones", publicaciones);
app.use("/api/comentarios", comentarios);






app.use((req, res) => {
  res.status(404).json({ error: true, mensaje: "El recurso del backend no fue encontrado" });
});



//Errores Globales(no 404)
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: true, mensaje: err.message || "Error interno del servidor" });
});



//------------------------------------------------------------------
const PORT = 4000;

connectDB({ alter: false }).then(() => {
  app.listen(PORT, () => {
    console.log(`API lista: http://localhost:${PORT}/api`);
  });
});


