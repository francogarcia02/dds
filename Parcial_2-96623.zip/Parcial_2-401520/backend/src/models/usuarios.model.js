import { DataTypes } from "sequelize";

const usuariosAttributes = {
  id: { 
    primaryKey: true, 
    autoIncrement: true, 
    type: DataTypes.INTEGER 
  },
  nombre: { 
    type: DataTypes.STRING, 
    allowNull: false ,
    validate: { notEmpty: true },
    set(value) {
      this.setDataValue("nombre", value.trim())
    }
  },
  correo: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
    validate: { isEmail: true ,notEmpty: true},
    set(value) {
      this.setDataValue("correo", value.trim())
    }
  },
  ciudad: { 
    type: DataTypes.STRING, 
    allowNull: false ,
    validate: { notEmpty: true },
    set(value) {
      this.setDataValue("ciudad", value.trim())
    }
  }
};

const usuariosMethods = { tableName: "usuarios", timestamps: false };

const UsuariosModel = { usuariosAttributes, usuariosMethods };
export { UsuariosModel };
