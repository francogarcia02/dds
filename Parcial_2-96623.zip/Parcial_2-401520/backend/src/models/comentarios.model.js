import { DataTypes } from "sequelize";

const comentariosAttributes = {
    id: {
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER
    },
    nombre: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: { notEmpty: true },
        set(value) {
        this.setDataValue("nombre", value.trim())
    }
    },
    correo: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: { isEmail: true , notEmpty: true},
        set(value) {
        this.setDataValue("correo", value.trim())
    }
    },
    cuerpo: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: { notEmpty: true },
        set(value) {
        this.setDataValue("cuerpo", value.trim())
    }
    },
    publicacionId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    }
};

const comentariosMethods = {
    tableName: "comentarios",
    timestamps: false
};

const ComentariosModel = { comentariosAttributes, comentariosMethods };

export { ComentariosModel };
