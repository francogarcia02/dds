import { DataTypes } from "sequelize";

const publicacionesAttributes = {
    id: {
        primaryKey: true,
        autoIncrement: true,
        type: DataTypes.INTEGER
    },
    titulo: {
        type: DataTypes.STRING,
        allowNull: false ,
        validate: { notEmpty: true },
        set(value) {
        this.setDataValue("titulo", value.trim())
    }
    },
    cuerpo: {
        type: DataTypes.TEXT,
        allowNull: false,
        validate: { notEmpty: true },
        set(value) {
        this.setDataValue("cuerpo", value.trim())
    }
    },
    usuarioId: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
};

const publicacionesMethods = {
    tableName: "publicaciones",
    timestamps: false
};

const PublicacionesModel = { publicacionesAttributes, publicacionesMethods };

export { PublicacionesModel };
