import { sequelize } from "../db.js";
import { UsuariosModel } from "./usuarios.model.js";
import { PublicacionesModel } from "./publicaciones.model.js";
import { ComentariosModel } from "./comentarios.model.js";

export const Usuario = sequelize.define("Usuario",UsuariosModel.usuariosAttributes,UsuariosModel.usuariosMethods);

export const Publicacion = sequelize.define("Publicacion",PublicacionesModel.publicacionesAttributes,PublicacionesModel.publicacionesMethods);

export const Comentario = sequelize.define("Comentario",ComentariosModel.comentariosAttributes,ComentariosModel.comentariosMethods);

/*
sequelize.models.Usuario = Usuario
sequelize.models.Publicacion = Publicacion
sequelize.models.Comentario = Comentario
*/
//-------------------------------------------------------------------------------

Usuario.hasMany(Publicacion, { foreignKey: "usuarioId", onDelete: "CASCADE" });
Publicacion.belongsTo(Usuario, { foreignKey: "usuarioId" });

Publicacion.hasMany(Comentario, { foreignKey: "publicacionId", onDelete: "CASCADE" });
Comentario.belongsTo(Publicacion, { foreignKey: "publicacionId" });

