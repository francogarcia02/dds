import { Router } from "express";
import { Comentario } from "../models/index.js";

const r = Router();


r.get("/", async (req, res, next) => {
  try {
    const lista = await Comentario.findAll({ order: [["id", "ASC"]] });
    res.json(lista);
  } catch (e) { next(e); }
});


r.delete("/:id", async (req, res, next) => {
  try {
    const c = await Comentario.findByPk(req.params.id);
    if (!c) return res.status(404).json({ error: true, mensaje: "Comentario no encontrado" });
    await c.destroy();
    res.status(204).end();
  } catch (e) { next(e); }
});

export default r;
