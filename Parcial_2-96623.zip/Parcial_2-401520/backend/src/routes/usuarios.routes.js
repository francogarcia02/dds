import { Router } from "express";
import { Usuario, Publicacion } from "../models/index.js";

const r = Router();


r.get("/", async (_req, res, next) => {
  try {
    const usuarios = await Usuario.findAll({ order: [["id", "ASC"]] });
    res.json(usuarios);
  } catch (e) { next(e); }
});


r.get("/:id", async (req, res, next) => {
  try {
    const u = await Usuario.findByPk(req.params.id);
    if (!u) return res.status(404).json({ error: true, mensaje: "Usuario no encontrado" });
    res.json(u);
  } catch (e) { next(e); }
});


r.post("/", async (req, res, next) => {
  try {
    const { nombre, correo, ciudad } = req.body;
    if (!nombre || !correo || !ciudad) {
      return res.status(400).json({ error: true, mensaje: "Datos incompletos" });
    }
    const nuevo = await Usuario.create({ nombre, correo, ciudad });
    res.status(201).json(nuevo);
  } catch (e) {
    if (e.name === "SequelizeUniqueConstraintError") {
      return res.status(409).json({ error: true, mensaje: "El correo ya está registrado" });
    }
    if (e.name === "SequelizeValidationError") {
      return res.status(400).json({ error: true, mensaje: e.errors?.[0]?.message || "Datos inválidos" });
    }
    next(e);
  }
});


r.put("/:id", async (req, res, next) => {
  try {
    const u = await Usuario.findByPk(req.params.id);
    if (!u) return res.status(404).json({ error: true, mensaje: "Usuario no encontrado" });
    await u.update(req.body);
    res.json(u);
  } catch (e) {
    if (e.name === "SequelizeUniqueConstraintError") {
      return res.status(409).json({ error: true, mensaje: "El correo ya está registrado" });
    }
    if (e.name === "SequelizeValidationError") {
      return res.status(400).json({ error: true, mensaje: e.errors?.[0]?.message || "Datos inválidos" });
    }
    next(e);
  }
});


r.delete("/:id", async (req, res, next) => {
  try {
    const u = await Usuario.findByPk(req.params.id);
    if (!u) return res.status(404).json({ error: true, mensaje: "Usuario no encontrado" });
    await u.destroy();
    res.status(204).end();
  } catch (e) { next(e); }
});


r.get("/:id/publicaciones", async (req, res, next) => {
  try {
    const existe = await Usuario.findByPk(req.params.id);
    if (!existe) return res.status(404).json({ error: true, mensaje: "Usuario no encontrado" });

    const pubs = await Publicacion.findAll({
      where: { usuarioId: req.params.id },
      order: [["id", "ASC"]],
    });
    res.json(pubs);
  } catch (e) { next(e); }
});

export default r;
