import { Router } from "express";
import { Publicacion, Usuario, Comentario } from "../models/index.js";

const r = Router();


r.get("/", async (req, res, next) => {
  try {
    const { usuarioId } = req.query;

    // Opciones de consulta
    const where = {};
    if (usuarioId !== undefined) {
      const id = Number(usuarioId);
      if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({ error: true, mensaje: "usuarioId inválido" });
      }
      where.usuarioId = id;
    }

    const publicaciones = await Publicacion.findAll({
      where,
      include: [{ model: Usuario, attributes: ["id", "nombre", "correo", "ciudad"] }],
      order: [["id", "ASC"]],
    });

    res.json(publicaciones);
  } catch (e) { next(e); }
});


r.get("/:id", async (req, res, next) => {
  try {
    const p = await Publicacion.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: true, mensaje: "Publicación no encontrada" });
    res.json(p);
  } catch (e) { next(e); }
});


r.post("/", async (req, res, next) => {
  try {
    const { usuarioId, titulo, cuerpo } = req.body;
    if (!usuarioId || !titulo || !cuerpo)
      return res.status(400).json({ error: true, mensaje: "Datos incompletos" });

    const p = await Publicacion.create({ usuarioId, titulo, cuerpo });
    res.status(201).json(p);
  } catch (e) { next(e); }
});


r.put("/:id", async (req, res, next) => {
  try {
    const p = await Publicacion.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: true, mensaje: "Publicación no encontrada" });
    await p.update(req.body);
    res.json(p);
  } catch (e) { next(e); }
});


r.delete("/:id", async (req, res, next) => {
  try {
    const p = await Publicacion.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: true, mensaje: "Publicación no encontrada" });
    await p.destroy();
    res.status(204).end();
  } catch (e) { next(e); }
});


r.get("/:id/comentarios", async (req, res, next) => {
  try {
    const p = await Publicacion.findByPk(req.params.id, {
      include: { model: Comentario }
    });
    if (!p) return res.status(404).json({ error: true, mensaje: "Publicación no encontrada" });
    res.json(p.Comentarios);
  } catch (e) { next(e); }
});


r.post("/:id/comentarios", async (req, res, next) => {
  try {
    const p = await Publicacion.findByPk(req.params.id);
    if (!p) return res.status(404).json({ error: true, mensaje: "Publicación no encontrada" });

    const { nombre, correo, cuerpo } = req.body;
    if (!nombre || !correo || !cuerpo)
      return res.status(400).json({ error: true, mensaje: "Datos incompletos" });

    const c = await Comentario.create({ nombre, correo, cuerpo, publicacionId: p.id });
    res.status(201).json(c);
  } catch (e) { next(e); }
});

export default r;
