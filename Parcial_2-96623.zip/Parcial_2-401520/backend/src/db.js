import { Sequelize } from "sequelize";
import path from "node:path";
import fs from "node:fs";

const DB_DIR = path.resolve(process.cwd(), "data");
const DB_FILE = path.join(DB_DIR, "app.sqlite");

fs.mkdirSync(DB_DIR, { recursive: true });

export const sequelize = new Sequelize({
  dialect: "sqlite",
  storage: DB_FILE,
  logging: false
});

export async function connectDB({ alter = false } = {}) {
  await sequelize.authenticate();
  
  await sequelize.query("PRAGMA foreign_keys = ON");
  await sequelize.query("PRAGMA journal_mode = WAL");
  await sequelize.query("PRAGMA synchronous = NORMAL");

  await sequelize.sync({ alter });

  console.log("SQLite OK →", DB_FILE);
}
